1. The current zip file contains a scheduler framework.  To compile, input in the terminal:
  make

Then you can run it:
  ./Scheduler



2. For Bonus Assignment Three:
(1) Revise scheduler-impl.c (that is the only file you need to submit) to implement the MLFQ scheduler mentioned in Bonus Assignment Three.

(2) Your program should be compiled by:
   make

Submission: You only need to submit scheduler-impl.c.